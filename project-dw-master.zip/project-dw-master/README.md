![alt text](https://www.impacta.edu.br/themes/wc_agenciar3/images/logo-new.png)
## Projecto Gerenciamento de usuário


## Começando
Essas instruções farão com que você tenha uma cópia do projeto em execução na sua máquina local para fins de desenvolvimento e teste. Veja a implantação de notas sobre como implantar o projeto em um sistema ativo.

## Plataforma para execução do projeto

## Verifique já tem o node intalado

```php
node -v
```

## Caso não tenha siga a instrução a baixo

Para mais informações clique [aqui](https://nodejs.org/en/download) para a intalação do node


## Linguagem

```php
javascript
```

## Pré-requisitos

```php
Clonar o projecto
```



